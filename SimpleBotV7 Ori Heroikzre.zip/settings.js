require("./server/handler.js")

// >~~~~~~ Setting Bot & Owner  ~~~~~~~< //
global.owner = "6282340243800"
global.namabot = "Simple Bot V7" 
global.namaowner = "Heroikzre"
global.linkgc = 'https://chat.whatsapp.com/-'
global.packname = "Bot WhatsApp"
global.author = "-"
global.packname = 'Bot WhatsApp'
global.botname = 'Heroikzre Bot'
global.botname2 = 'Heroikzre Design'


// >~~~~~~~~ Setting Channel ~~~~~~~~~< //
global.idsaluran = "-@newsletter"
global.namasaluran = "-"
global.linksaluran = "https://whatsapp.com/channel/-"

// >~~~~ Setting Grup Reseller Panel ~~~~~< //
global.linkgrupresellerpanel = "https://chat.whatsapp.com/-"
global.apidigitalocean = "-"


// >~~~~~~~~ Setting Payment ~~~~~~~~~< //
global.dana = "081237300464"
global.ovo = "Belum Tersedia"
global.gopay = "Belum Tersedia"
global.qris = "https://files.catbox.moe/ipvmvm.jpg"
global.seabank = "901436426817"


//~~~~~~~~~~~~~~~~ Settings Panel ~~~~~~~~~~~~~~~~~~~~~~~//
global.apipanel = "ptlc_45n653smsyXEQBXWhJhF47aFKOLRPxWM3OkJJuwGYhO"
global.webpanel = "https://ryanofficial.zakzz.web.id"
global.serverpanel = "9cdcde1d"

//~~~~~~~~~~~ Setting Program Panel ~~~~~~~~~~~~//
global.apipanel2 = "ptlc_kqCOGxF3fTjWzdemf5dFsdTxJHHLuPfZvEg38U1jkwl"
global.webpanel2 = "https://derrymiff.vvip.my.id"
global.serverpanel2 = "120d8200"
// >~~~~~~~ Setting Orderkuota ~~~~~~~~< //

global.QrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214035011014326210303UMI51440014ID.CO.QRIS.WWW0215ID20253801852100303UMI5204541153033605802ID5925HEROIKZRE STORE OK22963696005KUKAR61057525162070703A016304B23A"
global.ApikeyOrderKuota = "498351617426016162296369OKCT5F3D5CD0401716106554D58981DA3ACD"
global.IdMerchant = "OK2296369"
global.pinH2H = "130928"
global.passwordH2H = "qwerty123"

global.ApikeyRestApi = "new"


// >~~~~~~~~ Setting Api Panel ~~~~~~~~< //

global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://-"
global.apikey = "-" // Isi api ptla
global.capikey = "-" // Isi api ptlc


// >~~~~~~ Setting Api Cloudflare ~~~~~~~< //

global.apitoken_cloudflare = "-"
global.accountid_cloudflare = "-"
global.email_cloudflare = "-@gmail.com"


// >~~~~~~~~ Setting Message ~~~~~~~~~< //

global.msg = {
wait: "Memproses Ya Bang , Mohon Bersabar ini bukan ujian ;-; . . .", 
owner: "*[ DITOLAK LAH ]*\nFitur Ini Cuman Buat Heroikzre Bang >.< !",
group: "*[ Akses Ditolak ]*\nFitur ini *cuman bisa dipakai di Grup OI* @.@ !!",
private: "*[ Akses DITOLAK ]*\nFitur ini *Rahasia*, Jadi Cuman Bisa Dipakai Di Privat Chat Yak :l !",
botAdmin: "*[ No ACCESS ]*\n*NO ACCESS Bjir*, Jadiin Dulu lah Admin _- !",
admin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk admin grup ya bang XD !!",
}



let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})